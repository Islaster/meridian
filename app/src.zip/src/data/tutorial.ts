import type { GameState } from "../state/types";

export type Pointer =
  | { kind: "exit"; id: string }
  | { kind: "npc"; id: string }
  | { kind: "action"; id: string }
  | { kind: "board" }
  | { kind: "shop" }
  | { kind: "wait" }
  | { kind: "rest" }
  | { kind: "menu" };

export interface Step {
  id: string;
  text: string;
  target?: string; // what to spotlight — a selector on data-tut
  done: (s: GameState) => boolean;
  allow?: (s: GameState, p: Pointer) => boolean; // absent = everything
}

export interface Tutorial {
  id: string;
  title: string;
  when: (s: GameState) => boolean;
  steps: Step[];
}

const at = (key: string) => `[data-tut="${key}"]`;

const has = (s: GameState, f: string) => s.done.includes(f);
const menu = (p: Pointer) => p.kind === "menu"; // the journal stays reachable in every step
const idle = (p: Pointer) => p.kind === "wait" || p.kind === "rest";
const status = (s: GameState, id: string) => s.quests[id]?.status;
const doneOr = (id: string) => (s: GameState) =>
  status(s, id) === "complete" || has(s, "inducted");
const action = (prefix: string) => (p: Pointer) =>
  p.kind === "action" && p.id.startsWith(prefix);
const walk = (p: Pointer) => p.kind === "exit" || idle(p) || menu(p);

// one explainer, once: each step is a quest of "A master's word", and the line is the truth
const MASTER: Step[] = [
  {
    id: "meet",
    text: "Six masters still teach in Caldermouth. Pick one, go where they teach — the ✦ leads — and hear the terms.",
    done: doneOr("a-masters-word"),
    allow: (_, p) => walk(p) || p.kind === "npc",
  },
  {
    id: "practice",
    text: "Nobody teaches a stranger. Practice where they teach — a session is four hours, two count a day — until they look up. Sleep when the day runs out.",
    done: doneOr("earn-the-eye"),
    allow: (_, p) => walk(p) || action("practice-")(p),
  },
  {
    id: "errands",
    text: "They've noticed. Now they'll ask for something, then something else. The journal tracks it; the ✦ leads.",
    done: doneOr("run-the-errands"),
  },
  {
    id: "oath",
    text: "Terms named. Take the oath — the short words open the common class now. A trial and a stat floor buy the trained one instead; that road stays open.",
    done: doneOr("the-short-words"),
    allow: (_, p) => walk(p) || action("oath-")(p),
  },
  {
    id: "class",
    text: "A name for what you are. Your master's quests are in the journal now — each one opens something the oath didn't.",
    done: (s) => has(s, "tut:class"),
  },
];

export const TUTORIALS: Tutorial[] = [
  {
    id: "opening",
    title: "The first morning",
    when: () => true,
    steps: [
      {
        id: "tracker",
        target: at("tracker"),
        done: (s) => has(s, "tut:tracker"),
        text: "This is the quest you're following. The ✦ on the ways out marks which one leads there.",
        allow: (_, p) => menu(p),
      },
      {
        id: "exits",
        target: at("exits"),
        done: (s) => has(s, "tut:exits"),
        text: "Every way out costs time — it's written on the door. Clocks and shops don't wait.",
        allow: (_, p) => menu(p),
      },
      {
        id: "menu",
        target: at("menu"),
        done: (s) => has(s, "tut:menu"),
        text: "The menu holds your bag, your sheet, your skills, and the journal. Everything you've been told is in there.",
        allow: (_, p) => menu(p),
      },
    ],
  },
  {
    id: "equip",
    title: "Something to wield",
    when: (s) => (s.bag.equipment ?? []).length > 0,
    steps: [
      {
        id: "equip",
        text: "You're carrying something you could wield. Open the menu, go to Inventory, and press Equip beside it. Nothing you carry does anything until it's in your hands.",
        done: (s) => !!s.player.equipment?.mainWeapon,
        allow: (_, p) => menu(p),
      },
    ],
  },
  {
    id: "master",
    title: "A master's word",
    when: (s) => s.quests["a-masters-word"]?.status === "taken",
    steps: MASTER,
  },
];
