import { Location, Npc } from "../data/world/locations";
import { isOpen } from "./time";
import { seed } from "./seed";
import type { GameState } from "../state/types";

// Is this place's roam out today? Dealt by the day, so it's the same answer on every replay.
export const roaming = (s: GameState, loc: Location) =>
  !!loc.roam && seed(`${s.time.dayId}:roam:${loc.id}`) < loc.roam.chance;

export const locationOfNpc = (npc: string) =>
  [...Location.registry.values()].find((l) => l.npcs.includes(npc))?.id;

// Where someone is: their week if they keep one, else their post while it's open, else home.
export function whereIs(s: GameState, id: string): string | undefined {
  const n = Npc.get(id);
  const shift = n.week.find(
    (w) =>
      (!w.days || w.days.includes(s.time.dayId % 7)) &&
      isOpen({ open: w.open, close: w.close }, s.time)
  );
  if (shift) return shift.at;
  const post = locationOfNpc(id);
  const working =
    !!post &&
    isOpen(Location.get(post).hours, s.time) &&
    isOpen(n.hours, s.time);
  if (working) return post;
  const home = n.home && (!n.home.when || s.done.includes(n.home.when));
  return home ? n.home!.location : undefined;
}

export const present = (s: GameState, loc: Location) =>
  [...Npc.registry.values()]
    .filter((n) => whereIs(s, n.id) === loc.id)
    .map((n) => n.id);

export function describeNow(s: GameState, loc: Location) {
  let text = loc.describe;
  for (const a of loc.after) if (s.done.includes(a.when)) text = a.describe;
  return text;
}
