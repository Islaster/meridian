import { useGame } from "../state/gamecontext";
import type { GameState } from "../state/types";
import { offered, takeName, leaveName } from "../systems/ledger";
import { progress } from "../systems/quests";
import { Skill } from "../data/skills";
import { SERIF, MenuButton } from "./cards";
import LedgerLine from "./ledgerline";
import { GRADE_NAME, graded } from "./grade";

// The Ledger's line: a 《Phantasm》 name, offered once, fully readable, taken or left. Shows wherever you are.
export default function Ledger() {
  const { state, changeState } = useGame();
  const c = offered(state);
  if (!c || state.player.hp <= 0) return null;
  const apply = (n: GameState) =>
    (Object.keys(n) as (keyof GameState)[]).forEach((k) =>
      changeState(k, n[k])
    );
  const opens = c.skills.map((id) => Skill.get(id).name);
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.86)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
        zIndex: 55,
      }}
    >
      <div
        style={{
          width: "min(560px, 100%)",
          background: "#000",
          border: "1px solid rgba(233,236,242,0.2)",
          padding: "28px 32px",
          color: "rgba(233,236,242,0.92)",
          font: `400 clamp(15px, 1.5vw, 19px) ${SERIF}`,
          display: "flex",
          flexDirection: "column",
          gap: 18,
        }}
      >
        <LedgerLine>《The Ledger》</LedgerLine>
        <div style={{ opacity: 0.7, lineHeight: 1.5 }}>
          A line opens at the edge of sight, in the pale hand that records. It
          has written a name.
        </div>
        <div style={{ fontSize: "1.3em", ...graded(c.grade) }}>
          {c.name}{" "}
          <span
            style={{ fontSize: "0.65em", opacity: 0.8, letterSpacing: "0.1em" }}
          >
            《{GRADE_NAME[c.grade]}》
          </span>
        </div>
        {c.describe && <div style={{ lineHeight: 1.5 }}>{c.describe}</div>}
        {opens.length > 0 && (
          <div style={{ opacity: 0.7, lineHeight: 1.5 }}>
            Opens: {opens.join(" · ")}
          </div>
        )}
        <div style={{ opacity: 0.7, lineHeight: 1.5 }}>
          No master stands behind it. Take it and it is yours, on top of every
          other name you hold, and its own work will follow in the journal.
          Leave it and the line closes; it does not open twice. The Ledger
          writes one such name, ever.
        </div>
        <div
          style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 6 }}
        >
          <MenuButton
            label="Take the name"
            onClick={() => apply(progress(takeName(c.id)(state), null))}
          />
          <MenuButton
            label="Leave it unwritten"
            onClick={() => apply(leaveName(c.id)(state))}
          />
        </div>
      </div>
    </div>
  );
}
